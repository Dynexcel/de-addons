from openerp import models, fields, api, exceptions, _


class event_event(models.Model):
    _inherit = 'event.event'

    x_trainer_id = fields.Many2one('res.partner', string='Trainer',
        default=lambda self: self.env.user.company_id.partner_id)
    x_noted_at_site = fields.Html( oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_within_service_champions = fields.Html(oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_for_site = fields.Html(oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_for_service_champions = fields.Html(oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_ship_to = fields.Char(string="Ship to")
    x_territory_manager = fields.Char(string="Territory Manager")
    x_shift = fields.Selection(selection=[('9hrs', '9Hrs'),('12hrs', '12Hrs'),('15hrs', '15Hrs'),('18hrs', '18Hrs'),('24hrs', '24Hrs')],string='Shift')
    x_shift_cut_out_time = fields.Selection(selection=[('1am', '01:00 AM'),('2am', '02:00 AM'),('3am', '03:00 AM'),('4am', '04:00 AM'),('5am', '05:00 AM'),('6am', '06:00 AM'),
                                                       ('7am', '07:00 AM'),('8am', '08:00 AM'),('9am', '09:00 AM'),('10am', '10:00 AM'),('11am', '11:00 AM'),('12am', '12:00 AM'),
                                                       ('1pm', '01:00 PM'),('2pm', '02:00 PM'),('3pm', '03:00 PM'),('4pm', '04:00 PM'),('5pm', '05:00 PM'),('6pm', '06:00 PM'),
                                                       ('7Pm', '07:00 PM'),('8pm', '08:00 PM'),('9pm', '09:00 PM'),('10pm', '10:00 PM'),('11pm', '11:00 PM'),('12pm', '12:00 PM'),],
                                            string='Shift Cut out Time')
    _sql_constraints = [
        ('ship_to_unique',
         'UNIQUE(x_ship_to)',
         "Can't be duplicate value for Ship to"),
    ]


class event_registration(models.Model):
    _inherit = 'event.registration'

    x_time_in = fields.Datetime(string="Time In")
    x_time_out = fields.Datetime(string="Time Out")
    x_age_range = fields.Selection(selection=[('less_than_15', 'Less than 15'),('15_to_20', '15 - 20'),('21_to_25', '21 - 25'),('26_to_30', '26 - 30'),('31_to_35', '31 - 35'),('36_to_40', '36 - 40'),('41_to_50', '41 - 50'),('above_50', 'Above 50')],string='Age Range')
    x_salary_range = fields.Selection(selection=[('less_than_5000', 'Less than 5000'),('5000_to_10000', '5000 - 10000'),('10000_to_15000', '10000 - 15000'),('greater_than_15000', 'Greater than 15000')],string='Salary Range')
    x_exp_range = fields.Selection(selection=[('less_than_1', 'Less than 1'),('1_to_3', '1 - 3'),('3_to_6', '3 - 6'),('6_to_10', '6 - 10'),('10_to_15', '10 - 15'),('greater_than_15', 'Greater than 15')],string='Exp. Range')
    x_pre_training = fields.Integer(string="Pre Training Score:")
    x_post_training = fields.Integer(string="Post Training Score:")
    x_smart_phone_availability = fields.Boolean('Smart Phone Availability')

    _defaults = {
        'x_smart_phone_availability': True,
    }

