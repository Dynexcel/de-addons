# -*- coding: utf-8 -*-
{
    'name': "Ecommerce Add Links",

    'summary': """ecommerce_add_links""",

    'description': """
        ecommerce_add_links:

    """,

    'author': "Dynexcel",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Test',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','board','hr_recruitment','hr'],

    'data': [
        'link_template.xml',

    ],

    # always loaded

    # only loaded in demonstration mode
    'demo': [

    ],
}