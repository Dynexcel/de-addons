# -*- coding: utf-8 -*-
from . import link_model