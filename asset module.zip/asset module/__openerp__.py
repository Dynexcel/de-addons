# -*- coding: utf-8 -*-
{
    'name': "Asset Extended Module1",

    'summary': """Asset Module Customized Form""",

    'description': """
        Asset Module:

    """,

    'author': "Dynexcel",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Maintenance',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','board','asset','hr'],

    'data': [
        'asset_form_view.xml'

    ],


    # always loaded

    # only loaded in demonstration mode
    'demo': [

    ],
}