[ NAME ]
address_extended


[ SUMMARY ]
Address - extended


[ AUTHOR ]
Rui Pedrosa Franco


[ VERSION ]



[ WEBSITE ]
http://pt.linkedin.com/in/ruipedrosafranco


[ CATEGORY ]
Localization


[ LICENSE ]
AGPL-3


[ DESCRIPTION ]

Adds three hierarchically dependent fields so that more info can be saved on addresses (typically, region, county, etc.).

MAKE SURE YOU CHECK MY OTHER MODULES AT... https://www.odoo.com/apps?search=rui+pedrosa+franco
                        


[ MENUS ]



[ VIEWS ]



[ REPORTS ]
