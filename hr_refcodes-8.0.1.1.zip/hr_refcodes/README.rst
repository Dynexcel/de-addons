adds reference codes fields for Employees and
Departments, and makes them visible and searchable in referencing fields.
