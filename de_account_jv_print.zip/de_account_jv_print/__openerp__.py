# -*- coding: utf-8 -*-
{
    'name': "Journal Voucher Print",

    'summary': """
        This Module is to show the print/preview of Journal Voucher Form""",

    'description': """
Qweb Report of Payment Form
====================
Qweb Reporting of odoo V9 to show the print/preview of Journal Form.

    """,

    'author': "Dynexcel",
    'website': "http://www.dynexcel.com",

    # Categories can be used to filter modules in modules listing
    # Check <odoo>/addons/base/module/module_data.xml of the full list
    'category': 'account',
    'version': '0.1',

    # Agregamos estas dependencias para el ejemplo, website lo ponemos para que sea editable en interfaz web
    'depends': ['base','account'],
    'data': [
        # cargamos las vistas de los reportes        
        # reporte sensillo recorrido en el mismo
        'views/report_de_account_jv_print.xml',            
        # Mostramos herencia de reportes, modificamos el header y footer por defecto
        'views/report_external_layout_header.xml',
        'views/report_external_layout_footer.xml',

        # cargamos los reportes
        'de_account_jv_print_report.xml',
    ],

    'demo': [
    ],

    'tests': [
    ],
}


    