# -*- coding: utf-8 -*-
from . import ecommerce_model
