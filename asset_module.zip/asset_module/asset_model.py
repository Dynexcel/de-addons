from openerp import models, fields, api, exceptions, _


class asset_asset1(models.Model):
    _inherit = 'asset.asset'

    x_employee_id = fields.Many2one('hr.employee', 'Employee')
    x_asset_type = fields.Selection(selection=[('sim', 'Sim'),('mobile', 'Mobile'),('Vehicle', 'vehicle'),('laptop', 'Laptop'),('others', 'Others')],string='Asset Type')
    x_issue_date = fields.Date(string="Issue Date")