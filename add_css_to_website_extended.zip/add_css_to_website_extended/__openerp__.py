{
    'name': 'Add to css extended',
    'summary': 'Lovely Odoo Theme',
    'version': '1.0',
    'description': """

==================
        """,
    'category': 'Theme/Ecommerce',
    'author': 'Vidhin Mehta',
    'depends': [
        'website'
    ],
    'data': [
        'views/assets.xml',
    ],
    'installable': True,
}
