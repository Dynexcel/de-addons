{
    'name': 'Theme Rayen Sticky Menu',
    'summary': 'Lovely Odoo Theme',
    'version': '1.0',
    'description': """
Sticky Menu
==================
        """,
    'website': 'www.templates-odoo.com',
    'category': 'Theme/Ecommerce',
    'author': 'DevTalents',
    'depends': [
        'theme_rayen'
    ],
    'data': [
        'views/assets.xml',
    ],
    'installable': True,
}
