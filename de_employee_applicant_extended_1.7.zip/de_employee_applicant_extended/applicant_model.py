from openerp import models, fields, api, exceptions, _


class employee_form(models.Model):
    _inherit = 'hr.applicant'

    x_spouse_name = fields.Char('Spouse Name')
    x_father_name = fields.Char('Father Name')
    x_applicant_cnic = fields.Char(string='CNIC#')
    x_date_o_b = fields.Date(default=fields.Date.today)
    x_gender = fields.Selection(selection=[('male', 'Male'),('female', 'Female')],string='Gender')
    x_marital_status = fields.Selection(selection=[('single', 'Single'),('married', 'Married'),('widower', 'Widower'),('divorced', 'Divorced')],string='Marital Status')
    x_language = fields.Selection(selection=[('english', 'English'),('urdu', 'Urdu'),('punjabi', 'Punjabi'),('pashto', 'Pashto')],string='Language')

    x_experience_in_year = fields.Char('Experience',size=4)
    x_designation = fields.Char('Designation')
    x_organization = fields.Char('Organization')
    x_total_experience = fields.Char('Total Experience(s)',size=4)

    x_date_in = fields.Date(string="Date In")
    x_date_out = fields.Date(string="Date Out")
    x_ssalary_structure = fields.Many2one('hr.payroll.structure', string="Salary Structure")


class partner_form(models.Model):
    _inherit = 'res.partner'

    x_district = fields.Char('District/Agency')
    x_region = fields.Char('Region')
    x_tehsil = fields.Char('Tehsil/Town')
    x_uc = fields.Char('UC')
    x_uc_code = fields.Char('UC Code')
    x_area = fields.Char('Area')
    x_area_code = fields.Char('Code')
    x_sub_area = fields.Char('Sub Area')
    x_cnic = fields.Char(string="CNIC#")
    x_mobile = fields.Char(string="Mobile",required=True)
    x_marital_status_partner = fields.Selection(selection=[('single', 'Single'),('married', 'Married'),('widower', 'Widower'),('divorced', 'Divorced')],string='Marital Status')
    x_gender_partner = fields.Selection(selection=[('male', 'Male'),('female', 'Female')],string='Gender')


class partner_form1(models.Model):
    _inherit = 'hr.employee'

    x_working_address = fields.Many2one('res.partner', string="Working Address2")
    x_postal_address = fields.Many2one('res.partner', string="Postal Address")
    x_tribe = fields.Char(string="Tribe")
    x_lang = fields.Char(string="Language")

    def onchange_x_address_id(self, cr, uid, ids, address, context=None):
        if address:
            address = self.pool.get('res.partner').browse(cr, uid, address, context=context)
            return {'value': {'work_phone': address.phone, 'mobile_phone': address.mobile}}
        return {'value': {}}


class job_position(models.Model):
    _inherit = 'hr.job'

    x_job_type = fields.Selection(selection=[('sm', 'SM'),('tpsm', 'TPSM'),('uccso', 'UCCSO'),('dhcso', 'DHCSO'),('fcm', 'FCM'),('fcw', 'FCW'),('chw', 'CHW'),('ai', 'AI'),('dso', 'DSO'),('as', 'AS'),('us', 'US'),('ahcso', 'AHCSO'),('cm', 'CM'),('aic', 'AIC')],string='Job Type')