[ NAME ]
hr_holidays_reminders


[ SUMMARY ]
HR Holidays - requests reminders


[ AUTHOR ]
Rui Pedrosa Franco


[ VERSION ]



[ WEBSITE ]
http://pt.linkedin.com/in/ruipedrosafranco


[ CATEGORY ]
Human Resources


[ LICENSE ]
AGPL-3


[ DESCRIPTION ]

- adds a field to the request form, so that a deadline can be set
- in 'Leave Requests to Approve' and 'Allocation Requests to Approve' tree views, lines become orange whenever deadlines have been set
- on confirmation: sends email to the employee's manager
- on refusal/approval: sends email to the employee

NOTE:
A valid email server configuration is required
                    
MAKE SURE YOU CHECK MY OTHER MODULES AT... https://www.odoo.com/apps?search=rui+pedrosa+franco
                    


[ MENUS ]



[ VIEWS ]



[ REPORTS ]
