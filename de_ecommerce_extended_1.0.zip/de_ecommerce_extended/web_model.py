from openerp import models, fields, api, exceptions, _


class product_template(models.Model):
    _inherit = ["product.template", "website.seo.metadata"]
    _name = 'product.template'

    x_sku = fields.Char(string="SKU:")
    x_hs_code = fields.Char(string="HS Code:")