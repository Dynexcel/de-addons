# -*- coding: utf-8 -*-
{
    'name': "ecommerce app extension",

    'summary': """Ecommerce website Customized Form""",

    'description': """
Managing Ecommerce App in Odoo.
===============================
By adding following fields:
    * SKU:
    * HS Code:
    """,

    'author': "Dynexcel",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Sale',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base','board','website_sale','website', 'sale'],

    'data': [
        'web_product_view.xml',
        'templates.xml',
    ],


    # always loaded

    # only loaded in demonstration mode
    'demo': [

    ],
}