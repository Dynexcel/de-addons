{
    'name': 'Add CSS into Theme(v2)',
    'summary': 'Customize Odoo Theme',
    'version': '1.0',
    'description': """

==================
        """,
    'category' : 'Website',
    'author': 'Dynexcel',
    'depends': [
        'website'
    ],
    'data': [
        'views/assets.xml',
    ],
    'installable': True,
    'css': ['static/src/css/custom.css'],
}
