
# -*- coding: utf-8 -*-

from openerp import models, fields, api, _
from openerp.exceptions import ValidationError


class product_template(models.Model):
    _inherit = "product.template"

    website_order_limit = fields.Float(related='product_variant_ids.website_order_limit', store=True)
    apply_order_limit = fields.Boolean(related='product_variant_ids.apply_order_limit', string="Apply Order Limit", store=True)


class product_product(models.Model):
    _inherit = "product.product"

    @api.one
    @api.constrains('website_order_limit','apply_order_limit')
    def _check_order_limit(self):
        if self.apply_order_limit and self.website_order_limit <= 0.00:
            raise ValidationError(_('Order limit quantity should not be less than or equal to Zero'))

    apply_order_limit = fields.Boolean(string="Apply Order Limit")
    website_order_limit = fields.Float(string="Order Limit",help="Tick this box if you want to give Order Limit else no-limit.")


class sale_order_line(models.Model):
    _inherit = "sale.order.line"

    website_order_limit = fields.Float(related='product_id.website_order_limit', store=True)
    is_limit = fields.Boolean(string="Limit Contain")

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
