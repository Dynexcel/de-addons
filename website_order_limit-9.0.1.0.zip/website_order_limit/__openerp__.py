# -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd. See LICENSE file for full copyright and licensing details.
{
    'name': 'Website Shop Product Order Limit',
    'category': 'Website',
    'summary': 'Website Shop Product Order Limit On E-commerce',
    'author': 'Probuse Consulting Service Pvt. Ltd.',
    'website': 'https://www.probuse.com',
    'price': 90.00,
    'currency': 'EUR',
    'version': '1.0',
    'description': """

This module add features on E-commerce order limit based on product variants.

tags:
product order limit
website order limit
web order limit
shop order limit
eshop order limit
eshop product limit
product limit
shop product limit
ecommerce product limit
ecommerce limit
E-commerce product limit
set order limit 
set product order quantity
limited product
""",
    'depends': ['website','product','stock','website_sale'],
    'data': [
        'views/template.xml',
        'views/product_view.xml',
        'views/product_website_view.xml',
    ],
    'demo': [],
    'qweb': [
    ],
    'installable': True,
    'auto_install': False,
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
