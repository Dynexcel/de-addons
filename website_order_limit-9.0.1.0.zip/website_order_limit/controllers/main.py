# -*- coding: utf-8 -*-
import werkzeug

from openerp import SUPERUSER_ID
from openerp import http
from openerp import tools
from openerp.http import request
from openerp.tools.translate import _
from openerp.addons.website.models.website import slug
from openerp.addons.website_sale.controllers.main import website_sale

class website_sale(website_sale):
    
    def get_attribute_value_ids(self, product):
        """ We add new arguments apply_order_limit, website_order_limit"""
        res = super(website_sale, self).get_attribute_value_ids(product)
        product_obj = request.registry['product.product']
        for attributes in res:
            product = product_obj.browse(request.cr,request.uid, attributes[0])
            attributes.append(product.website_order_limit)
            attributes.append(1) if product.apply_order_limit == 1 else attributes.append(0)
        return res
    
    #===========================
    #Order limit
    #===========================
    @http.route(['/shop/order_limit'], type='http', auth="public", website=True)
    def order_limit(self, **post):
        cr, uid, context, registry = request.cr, request.uid, request.context, request.registry

        order = request.website.sale_get_order(context=context)
        values = {
            'website_sale_order': order
        }
        return request.website.render("website_order_limit.order_limit", values)
        
    @http.route(['/shop/checkout'], type='http', auth="public", website=True)
    def checkout(self, **post):
        cr, uid, context = request.cr, request.uid, request.context

        order = request.website.sale_get_order(force_create=1, context=context)
        
        for line in order.order_line:
            if line.product_id.apply_order_limit:
                if line.product_uom_qty > line.website_order_limit:
                    return request.redirect("/shop/order_limit")

        return super(website_sale, self).checkout(**post)
