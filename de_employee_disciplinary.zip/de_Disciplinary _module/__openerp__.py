# -*- coding: utf-8 -*-
{
    'name': "de_Disciplinary_Action_Extended_Module",

    'summary': """Disciplinary Action Form""",

    'description': """
        Disciplinary Action module for managing employee

    """,

    'author': "Dynexcel",
    'website': "http://www.dynexcel.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','hr'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'disciplinary_view.xml',

    ],
    # only loaded in demonstration mode
    'demo': [

    ],
}