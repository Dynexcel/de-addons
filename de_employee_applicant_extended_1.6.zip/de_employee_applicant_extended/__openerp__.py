# -*- coding: utf-8 -*-
{
    'name': "Employee, Applicant Module Extension",

    'summary': """Employee Directory and Recruitment Process Module customize form""",

    'description': """
Managing Employee Directory and Recruitment Process in Odoo.
============================================================
By adding following feature:
    * Following address related fields in partner form:
        District,
        Tehsil,
        UC,
        Area,
        Code,
        Sub Area,
        Region,
        CNIC,
        Mobile,
        Marital Status,
        Gender
    * Personal information and Professional experience group of fields in Applicant Form:
        * Personal Information
            Spouse Name,
            Father Name,
            Date of Birth,
            Gender,
            CNIC#,
            Marital Status,
            Language,
        * Professional Experience
            Organization,
            Experience,
            Designation,
            Total Experience(s)
    * Following address fields in Employee form:
            Working Address2,
            Postal Address,
            Tribe,
            Language,
            ID
    """,

    'author': "Dynexcel",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human_Resources',
    'version': '1.6',

    # any module necessary for this one to work correctly
    'depends': ['base','board','hr_recruitment','hr'],

    'data': [
        'applicant_form_view.xml',

    ],

    # always loaded

    # only loaded in demonstration mode
    'demo': [

    ],
}