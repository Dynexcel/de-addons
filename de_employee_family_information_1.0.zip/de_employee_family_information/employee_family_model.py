from openerp import models, fields, api, exceptions, _


class employee_family_form(models.Model):
    _inherit = 'hr.employee'

    x_father_cnic = fields.Char(string="Father's CNIC#")
    x_mother_cnic = fields.Char(string="Mother's CNIC#")