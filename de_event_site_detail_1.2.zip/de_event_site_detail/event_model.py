from openerp import models, fields, api, exceptions, _


class event_event(models.Model):
    _inherit = 'event.event'

    x_site_detail = fields.One2many('event.site.detail', 'x_site', string="Site Details")


class event_site(models.Model):
    _name = 'event.site.detail'
    _description = 'Event Site Detail'

    x_no_of_attendees = fields.Integer(string="No. of staff(s)")
    x_job_position = fields.Many2one("res.partner.job_position","Job Position",oldname="job_position")
    x_site = fields.Many2one('event.event', string='Detail')
