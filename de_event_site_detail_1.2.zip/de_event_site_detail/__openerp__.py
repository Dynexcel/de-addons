# -*- coding: utf-8 -*-
{
    'name': "Event Site Detail",

    'summary': """Event Module Customized Form""",

    'description': """
Managing Event Module in Odoo.
=========================================
By creating new tab Site Detailand adding following fields in Editable treeview in event form:
    * Department
    * No. of attendees
    """,

    'author': "Dynexcel",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Marketing',
    'version': '1.2',

    # any module necessary for this one to work correctly
    'depends': ['base','board','event','hr'],

    'data': [
        'event_form_view.xml'

    ],


    # always loaded

    # only loaded in demonstration mode
    'demo': [

    ],
}