# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
#################################################################################
from openerp.osv import fields, osv

class pos_order(osv.osv):
	_inherit = 'pos.order'
	_columns = {
	'is_return_order':fields.boolean('Return Order', copy=False),
	'return_order_id':fields.many2one('pos.order', 'Return Order of', readonly=True, copy=False),
	'return_status': fields.selection([('-', 'None'),
                                   ('Fully-Returned', 'Fully Returned'),
                                   ('Partially-Returned', 'Partially Returned'),
                                   ('Non-Returnable', 'Non-Returnable')],
                                  'Return Status', readonly=True, copy=False),
	}
	_defaults = {
	'return_status':'-'
	}

