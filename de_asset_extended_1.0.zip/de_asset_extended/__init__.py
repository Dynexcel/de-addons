# -*- coding: utf-8 -*-
from . import asset_model
