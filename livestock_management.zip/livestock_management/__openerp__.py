# -*- coding: utf-8 -*-
{
    'name': "Administración Ganadera",

    'summary': """
        Gestiona Fincas, Corrales y el ganado en ellas""",

    'description': """
        Este módulo permite la correcta gestión de cabezas de ganado, permitiendo llevar un control sobre su nutrición, vacunas, genética, Etc.
    """,

    'author': "HM Consulting",
    'website': "http://www.odoohonduras.com",
    'category': 'LivesStock',
    'version': '0.1',
    'depends': [
        'base',
        'stock',
    ],

    # always loaded
    'data': [
        #'security/ir.model.access.csv',
        'templates.xml',
        'views/livestock_embryo_view.xml',
        'views/livestock_animal_view.xml',
        'views/livestock_corral_view.xml',
        'views/livestock_farm_view.xml',
        'views/livestock_event_view.xml',
        'views/livestock_disease_view.xml',
        'views/livestock_sanitary_protocol_view.xml',
        'views/livestock_weighing_view.xml',
        'views/livestock_nutrition_view.xml',
        'views/livestock_specie_animal_view.xml',
        'views/livestock_race_animal_view.xml',
        'views/livestock_color_animal_view.xml',
        'views/livestock_status_animal_view.xml',
    ],
    'installable': True,
    'auto_install': False,
}
