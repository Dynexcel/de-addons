# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_disease(models.Model):
    _name = 'livestock.disease'
    _description = "Livestock Disease model"
    _order = "name desc"

    # Fields of the Disease Model
    name =  fields.Char(string='Identificador', size=8, required=True)
    disease_date = fields.Datetime(string= 'Fecha', required=True, default=datetime.now())
    diagnostician = fields.Char(string='Diagnosticador', require = True ,size=30, default = lambda self: self.env.user.name)
    exam = fields.Text(string='Exámenes Médicos', required=True)
    observation = fields.Text(string='Observaciones', required=False)
    symptoms = fields.Text(string='Síntomas', required=True)
    veterinarian = fields.Char(string='Veterinario', required=True)
    exam_result = fields.Text(string='Resultados de Exámenes', required=False, help="Results of the exams")
    treatment = fields.Text(string='Tratamiento', required=False)
    animal_id = fields.Many2one('livestock.animal', string='Animal', ondelete='cascade', index=True)
    sanitary_protocol_ids = fields.One2many('livestock.sanitary.protocol', 'disease_id', copy = False)
    active = fields.Boolean(string='Activo', default=True)
    

class livestock_sanitary_protocol(models.Model):
    _name = 'livestock.sanitary.protocol'
    _description = "Livestock Sanitary Protocol model"
    _order = "treatment_date desc"

    # Fields of the Sanitary Protocol Model
    treatment_applier = fields.Char(string='Persona que aplica el Tratamiento', required=True)
    treatment_supervisor = fields.Char(string='Supervidor', required=True)
    treatment_date = fields.Datetime(string= 'Fecha de Tratamiento', required=True, default = datetime.now())
    observation = fields.Text(string='Observaciones', required=False)
    disease_id = fields.Many2one('livestock.disease', string='Enfermedades', ondelete='cascade', index=True)     
    active = fields.Boolean(string='Activo', default=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
