# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_specie_animal(models.Model):
    _name = 'livestock.specie.animal'
    _description = "Configuration Model Animal Specie in Livestock"
    _order = "name"

    # Fields of the Configuration Animal Model
    name = fields.Char(string='Especie', index=True, required=True)
    description = fields.Text(string='Descripción', size=500)
    #animal_id = fields.Many2one(comodel_name='livestock.animal', string='Animal', ondelete='cascade', index=True)
    animal_id = fields.One2many('livestock.animal', 'specie_id', copy=False)
    race_ids = fields.One2many('livestock.race.animal', 'specie_id', string='Raza', copy=False)
    active = fields.Boolean(string='Activo', default=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
