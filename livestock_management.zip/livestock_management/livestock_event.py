    # -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_event(models.Model):
    _name = 'livestock.event'
    _description = "Livestock Event Model"
    _order = "event_date desc"


    # Fields of the Event Model
    name = fields.Char(string='Nombre de la Vacuna', size=20, required=True)
    description = fields.Text(string='Descripción', required=True)
    event_date = fields.Datetime(string='Fecha', required=True, default=datetime.now())
    responsible = fields.Char(string='Responsable', required=True, size=30, default=lambda self: self.env.user.name)
    animal_id = fields.Many2one('livestock.animal', string='Animal', ondelete='cascade', index=True)
    active = fields.Boolean(string='Activo', default=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
