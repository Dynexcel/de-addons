# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _
#from odoo.exceptions import Warning

class livestock_corral(models.Model):
    _name = 'livestock.corral'
    _inherits = {'stock.warehouse': 'wharehouse_id'} 
    _description = "Livestock Corral model"
    _order = "wharehouse_id desc"

    def _purpose_corral_selection(self):
        return(('breeding', _("Cría")),
               ('fattening', _("Engorde")),
               ('mating', _("Monta")),
               ('milking', _("Ordeño")),
               ('rest', _("Descando")))

    @api.one
    @api.depends('animal_ids')
    def _animals_amount_compute(self):
        self.animals = 0
        if self.id:
            query = """
            SELECT COUNT(id) 
            FROM livestock_animal 
            WHERE corral_id = %s 
            """
            self.env.cr.execute(query, (self.id,))
            reg = self.env.cr.fetchone()
            if reg[0]:
                self.animals = reg[0]

    def _topography_corral_selection(self):
        return(('flat', _("Plana")),
               ('soft_undulating', _("Semi Ondulada")),
               ('undulating', _("Ondulada")),
               ('broken', _("Quebrada")))

    def _water_corral_selection(self):
        return(('fountains', _("Fuentes")),
               ('streams', _("Arrollos")),
               ('aqueducts', _("Acueductos")),
               ('ditch', _("Charcos")),
               ('other', _("Other")))

    # Fields of the Corral Model
    wharehouse_id = fields.Many2one('stock.warehouse', string='Nombre del Corral', required=True, ondelete='cascade', select=True, auto_join=True)
    purpose = fields.Selection(string='Propósito', selection=_purpose_corral_selection, required=True)
    hectares = fields.Float(string='Hectareas', digits=(7, 2), required=True)
    topography = fields.Selection(string='Topografía', selection=_topography_corral_selection, required=True)
    grass_prevalent = fields.Text(string='Pasto Prevaleciente', required=False)
    bush_prevalent = fields.Text(string='Maleza Prevaleciente', required=False)
    drinking_water = fields.Selection(string='Fuente de Agua', selection=_water_corral_selection, required=True)
    animals = fields.Integer(string='Animales Dentro', copy=False, compute='_animals_amount_compute')
    observation = fields.Text(string='Observaciones', required=False)
    entry_date = fields.Date(string='Entry Date', default=None)
    rest_date = fields.Date(string='Rest Date', default=None)
    farm_id = fields.Many2one('livestock.farm', string='Finca', required=True, ondelete='cascade', index=True)
    animal_ids = fields.One2many('livestock.animal', 'corral_id', copy=False)
    active = fields.Boolean(string='Activo', default=True, help="Enable/Disable corral record")

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
