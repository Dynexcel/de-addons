# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_status_animal(models.Model):
    _name = 'livestock.status.animal'
    _description = "Livestock Configuration States Animal Model"
    _order = "name"

    # Fields of the Configuration Animal Model
    name = fields.Char(string='Estatus', index=True, required=True)
    gender = fields.Selection(string='Género', selection=[('female', _("Female")), ('male', _("Male"))], required=False)
    description = fields.Text(string='Descripción', size=500)
    animal_id = fields.One2many('livestock.animal', 'status_id', copy=False)
    active = fields.Boolean(string='Activo', default=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
