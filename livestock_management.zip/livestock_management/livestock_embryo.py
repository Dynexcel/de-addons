# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_embryo(models.Model):
    _name = 'livestock.embryo'
    _description = "Livestock Embryo model"
    _order = "id desc"

    def _phase_embryo_selection(self):
        return(('mo', _("Morula")),
               ('cm', _("Compact Morula")),
               ('eab', _("Early Blastocyst")),
               ('exb', _("Expanded Blastocyst")),
               ('hb', _("Hatched Blastocyst")))

    def _quality_embryo_selection(self):
        return(('q1', _("Quality 1")),
               ('q2', _("Quality 2")),
               ('q3', _("Quality 3")),
               ('q4', _("Quality 4")))

    # Fields of the Embryo Model
    name = fields.Char(string='Identificador', size=8, required=True, select=True)
    species_id =  fields.Many2one(comodel_name='livestock.specie.animal', string='Especie', required=True, ondelete='set null')
    race_id = fields.Many2one(comodel_name='livestock.race.animal', string='Raza', required=True, ondelete='set null')
    mother = fields.Many2one('livestock.animal', string='Madre', ondelete='set null', index=True, domain=[('gender','=','female')])
    father = fields.Many2one('livestock.animal', string='Padre', ondelete='set null', index=True, domain=[('gender','=','male')])
    phase = fields.Selection(string='Fase', selection=_phase_embryo_selection, required=True)
    quality = fields.Selection(string='Calidad', selection=_quality_embryo_selection, required=True)
    embryo_date = fields.Date(string='Creado', default=datetime.now(), required=True)
    farm = fields.Char(string='Finca', size=25)
    responsible = fields.Char(string='Responsable', size=25, required=True, default=lambda self: self.env.user.name)
    active = fields.Boolean(string='Activo', default=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
