# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_race_animal(models.Model):
    _name = 'livestock.race.animal'
    _description = "Configuration Model Animal Race in Livestock"
    _order = "name"

    # Fields of the Configuration Animal Model
    name = fields.Char(string='Raza', index=True, required=True)
    description = fields.Text(string='Descripción', size=500)
    animal_id = fields.One2many('livestock.animal', 'race_id', copy=False)
    specie_id = fields.Many2one(comodel_name='livestock.specie.animal', string='Especie', ondelete='set null', index=True)
    color_ids = fields.One2many('livestock.color.animal', 'race_id', copy=False)
    active = fields.Boolean(string='Activo', default=True,)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
