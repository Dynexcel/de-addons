# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_nutrition(models.Model):
    _name = 'livestock.nutrition'
    _description = "Livestock Nutrition Model"
    _order = "name desc"

    def _administration_route_nutrition_selection(self):
        return(('orally', _("Orally")),
               ('sublingual', _("Sublingual")),
               ('intramuscular', _("Intramuscular")),
               ('intravenous', _("Intravenosa")),
               ('cutaneous', _("Cutánea")),
               ('subcutaneous', _("Subcutánea")),
               ('rectal', _("Rectal")))

    def _supporting_feature_nutrition_selection(self):
        return(('provender', _("Forraje")),
               ('supplement', _("Suplemento")))

    # Fields of the Event Model
    name = fields.Selection(string='Suplemento', required=True, selection=_supporting_feature_nutrition_selection)
    supplement_type = fields.Char(string='Tipo de Suplemento', size=25, required=True)
    nutrition_date = fields.Datetime(string='Fecha', required=True, default=datetime.now())
    manufacturing_lab = fields.Char(string='Laboratorio de Origen', size=20, required=True)
    batch_manufacture = fields.Char(string='Lote', size=20, required=True)
    dosage = fields.Text(string='Dosis', required=True)
    administration_route = fields.Selection(string='Vía de Administración', selection=_administration_route_nutrition_selection, required=True)
    application_frequency = fields.Char(string='Frecuencia', size=25, required=True)
    responsible = fields.Char(string='Responsable', required=True, size=30, default=lambda self: self.env.user.name)
    animal_id = fields.Many2one('livestock.animal', string='Animal', ondelete='cascade', index=True)
    active = fields.Boolean(string='Activo', default=True)

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
