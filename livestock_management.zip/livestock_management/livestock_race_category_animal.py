# -*- coding: utf-8 -*-

from datetime import datetime
from openerp import models, fields, api, _

class livestock_race_category_animal(models.Model):
    _name = 'livestock.race.category.animal'
    _description = "Livestock Configuration Race, Category and Species Animal Model"
    _order = "name, features_type asc"

    def _features_conf_animal_selection(self):
        return(('species', _("Especie")),
               ('race', _("Raza")),
               ('category', _("Categoría")))

    # Fields of the Configuration Animal Model
    name = fields.Selection(string='Características', index=True, selection=_features_conf_animal_selection, required=True)
    features_type = fields.Char(string='Tipo de Características', size=25, required=True)
    description = fields.Text(string='Descripción', size=500)
    active = fields.Boolean(string='Activo', default=True)

