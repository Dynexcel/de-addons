from openerp import models, fields, api, exceptions, _


class event_event(models.Model):
    _inherit = 'event.event'

    x_trainer_id = fields.Many2one('res.partner', string='Trainer',
        default=lambda self: self.env.user.company_id.partner_id)


class event_registration(models.Model):
    _inherit = 'event.registration'

    x_time_in = fields.Datetime(string="Time In")
    x_time_out = fields.Datetime(string="Time Out")
    x_salary_range = fields.Selection(selection=[('less_then_5000', 'Less Then 5000'),('5000_to_10000', '5000 - 10000'),('10000_to_15000', '10000 - 15000'),('greater_then_15000', 'Greater then 15000')],string='Salary Range')
    x_exp_range = fields.Selection(selection=[('less_then_1', 'Less Then 1'),('1_to_3', '1 - 3'),('3_to_6', '3 - 6'),('6_to_10', '6 - 10'),('10_to_15', '10 - 15'),('greater_then_15', 'Greater then 15')],string='Exp. Range')
    x_pre_training = fields.Integer(string="Pre Training Score:")
    x_post_training = fields.Integer(string="Post Training Score:")


class res_partner1(models.Model):
    _inherit = 'res.partner'

    x_cnic = fields.Char(string="CNIC#")