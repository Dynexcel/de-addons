**Steps to install theme**

1. Unzip "dependency.zip" in a seprate folder or go to "depencency_modules" folder.
2. Go to Theme folder, go to __openerp__.py uncomment modules under "73lines Depend Modules"
3. keep theme and dependent module in addons path.
4. update modules list before installing theme.

**or follow this video**

.. image::  installation-instruction.png
   :target: http://www.youtube.com/watch?v=96psYKrOTPo

**Theme Configuration**

.. image:: configuration.png
   :target: https://www.youtube.com/watch?v=UJayD8q8Tc4   