##############################################
#
# ChriCar Beteiligungs- und Beratungs- GmbH
# created 2009-07-09 18:08:09+02
##############################################
import tenant
