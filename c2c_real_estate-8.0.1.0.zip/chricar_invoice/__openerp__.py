# -*- coding: utf-8 -*-
{ 'sequence': 500,
"name"         : "Invoice"
, "version"      : "1.0"
, "author"       : "ChriCar Beteiligungs- und Beratungs- GmbH"
, "website"      : "http://www.chricar.at/ChriCar"
, "description"  : """defines the equipment properties
generated 2009-07-11 14:55:52+02"""
, "category"     : "Client Modules/Real Estate"
, "depends"      : ["chricar_room", "chricar_top"]
, "init_xml"     : []
, "demo"         : []
, "data"   : ["invoice_view.xml", "security/ir.model.access.csv"]
, "auto_install" : False
, "installable"  : True
, 'application'  : False
}
