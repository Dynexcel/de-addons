{ 'sequence': 500,
"name"         : "Equipment"
, "version"      : "1.0"
, "author"       : "ChriCar Beteiligungs- und Beratungs- GmbH"
, "website"      : "http://www.chricar.at/ChriCar"
, "description"  : """defines the equipment properties
generated 2009-07-11 14:41:58+02"""
, "category"     : "Client Modules/Real Estate"
, "depends"      : ["chricar_room","chricar_top"]
, "init_xml"     : []
, "demo"         : []
, "data"   : ["equipment_view.xml","security/ir.model.access.csv"]
, "auto_install" : False
, "installable"  : True
, 'application'  : False
}
