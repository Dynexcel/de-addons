from openerp import models, fields, api, exceptions, _


class Action(models.Model):
    _name = 'disciplinary.action'

    x_employee= fields.Many2one('hr.employee', ondelete='set null', string="Employee", index=True)
    x_revision = fields.Selection(selection=[('revision1', 'Revision 1'),('revision2', 'Revision 2'),('revision3', 'Revision 3')],string='Revision')
    x_type = fields.Selection(selection=[('warning1', 'Warning 1'),('warning2', 'Warning 2'),('explanation1', 'Explanation 1'),('explanation2', 'Explanation 2'),('showcause', 'Showcause')],string='Type')
    x_date = fields.Date(default=fields.Date.today)
    x_advised_by = fields.Char(string="Advised By")
    x_reasons = fields.Char(string="Reason")


