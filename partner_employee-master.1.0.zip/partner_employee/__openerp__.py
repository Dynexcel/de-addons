# -*- coding: utf-8 -*-
{
    'name': 'Partner Employee',
    'version': '1.0',
    'category': 'Hidden',
    'sequence': 14,
    'summary': '',
    'description': """
Partner Employee
================
Adds a boolean field "Employee" on partners.
    """,
    'author':  'Ingenieria ADHOC',
    'website': 'www.ingadhoc.com',
    'images': [
    ],
    'depends': [
        'base',
    ],
    'data': [
        'res_partner_view.xml',
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
