from openerp import models, fields, api, exceptions, _


class product_template(models.Model):
    _inherit = ["product.template", "website.seo.metadata"]
    _name = 'product.template'

    x_cbm_volume = fields.Float(string="CBM Volume")
    x_packaging_quantity = fields.Integer(string="Packaging Quantity")
