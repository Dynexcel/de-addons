from openerp import models, fields, api, exceptions, _


class employee_form(models.Model):
    _name = "hr.applicant"
    _inherit = 'hr.applicant'

    x_spouse_name = fields.Char('Spouse Name')
    x_father_name = fields.Char('Father Name')
    x_date_o_b = fields.Date(default=fields.Date.today)
    x_gender = fields.Selection(selection=[('male', 'Male'),('female', 'Female')],string='Gender')
    x_marital_status = fields.Selection(selection=[('single', 'Single'),('married', 'Married'),('widower', 'Widower'),('divorced', 'Divorced')],string='Marital Status')

    x_experience_in_year = fields.Char('Experience',size=4)
    x_designation = fields.Char('Designation')
    x_organization = fields.Char('Organization')
    x_total_experience = fields.Char('Total Experience(s)',size=4)


class partner_form(models.Model):
    _name = "res.partner"
    _inherit = 'res.partner'

    x_district = fields.Char('District/Agency')
    x_tehsil = fields.Char('Tehsil')
    x_uc = fields.Char('UC')
    x_area = fields.Char('Area')
    x_sub_area = fields.Char('Sub Area')