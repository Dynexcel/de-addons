# -*- coding: utf-8 -*-
{
    'name': "Payment Print",

    'summary': """
        Simple module to test some functionalities and make some examples related to the
        QWeb reporting facilities of Odoo V8""",

    'description': """
Qweb Report Examples
====================
Simple module to test some functionalities and make some examples related to the QWeb reporting facilities of Odoo V8

    'author': "Dynexcel",
    'website': "http://www.dynexcel.com",

    # Categories can be used to filter modules in modules listing
    # Check <odoo>/addons/account/payment_print.xml of the full list
    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base','hr'],
    'data': [
        # cargamos las vistas de los reportes        
        # reporte sensillo recorrido en el mismo
        'views/report_party_payment.xml',            
        # Mostramos herencia de reportes, modificamos el header y footer por defecto
        'views/report_external_layout_header.xml',
        'views/report_external_layout_footer.xml',

        # cargamos los reportes
        'party_payment_report.xml',
    ],

    'demo': [
    ],

    'tests': [
    ],
}
