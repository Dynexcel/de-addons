from openerp import models, fields, api, exceptions, _


class event_event(models.Model):
    _inherit = 'event.event'

    x_trainer_id = fields.Many2one('res.partner', string='Trainer',
        default=lambda self: self.env.user.company_id.partner_id)
    x_event_date = fields.Datetime(string="Event Date & Time")
    x_noted_at_site = fields.Html( oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_within_service_champions = fields.Html(oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_for_site = fields.Html(oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_for_service_champions = fields.Html(oldname='note', translate=True,
        readonly=False, states={'done': [('readonly', True)]})
    x_ship_to = fields.Char(string="Ship to")
    x_territory_manager = fields.Char(string="Territory Manager")
    x_shift = fields.Selection(selection=[('1hrs', '1Hrs'),('2hrs', '2Hrs'),('3hrs', '3Hrs'),('4hrs', '4Hrs'),('5hrs', '5Hrs'),('6hrs', '6Hrs'),
                                          ('7hrs', '7Hrs'),('8hrs', '8Hrs'),('9hrs', '9Hrs'),('10hrs', '10Hrs'),('11hrs', '11Hrs'),('12hrs', '12Hrs'),
                                          ('13hrs', '13Hrs'),('14hrs', '14Hrs'),('15hrs', '15Hrs'),('16hrs', '16Hrs'),('17hrs', '17Hrs'),('18hrs', '18Hrs'),
                                          ('19hrs', '19Hrs'),('20hrs', '20Hrs'),('21hrs', '21Hrs'),('22hrs', '22Hrs'),('23hrs', '23Hrs'),('24hrs', '24Hrs')],string='Shift')
    x_shift_cut_out_time = fields.Selection(selection=[('1:00', '01:00'),('2:00', '02:00'),('3:00', '03:00'),('4:00', '04:00'),('5:00', '05:00'),('6:00', '06:00'),
                                                       ('7:00', '07:00'),('8:00', '08:00'),('9:00', '09:00'),('10:00', '10:00'),('11:00', '11:00'),('12:00', '12:00')],
                                            string='Shift Cut out Time')
    x_safty_helmet = fields.Selection(selection=[('yes', 'Yes'),('no', 'No')],string='Safety Helmet')
    x_safty_glasses = fields.Selection(selection=[('yes', 'Yes'),('no', 'No')],string='Safety Glasses')
    x_safty_jacket = fields.Selection(selection=[('yes', 'Yes'),('no', 'No')],string='Safety Jacket')
    x_safty_gloves = fields.Selection(selection=[('yes', 'Yes'),('no', 'No')],string='Safety Gloves')
    x_safty_shoes = fields.Selection(selection=[('yes', 'Yes'),('no', 'No')],string='Safety Shoes')
    x_torch = fields.Selection(selection=[('yes', 'Yes'),('no', 'No')],string='Torch')
    x_total_ppes = fields.Integer(string="Total PPES available at Site")
    x_trainer_remarks = fields.Char(string="Remarks by Trainer on PPES")

    _sql_constraints = [
        ('ship_to_unique',
         'UNIQUE(x_ship_to)',
         "Can't be duplicate value for Ship to"),
    ]


class event_registration(models.Model):
    _inherit = 'event.registration'

    x_time_in = fields.Datetime(string="Time In")
    x_time_out = fields.Datetime(string="Time Out")
    x_age_range = fields.Selection(selection=[('less_than_15', 'Less than 15'),('15_to_20', '15 - 20'),('21_to_25', '21 - 25'),('26_to_30', '26 - 30'),('31_to_35', '31 - 35'),('36_to_40', '36 - 40'),('41_to_50', '41 - 50'),('above_50', 'Above 50')],string='Age Range')
    x_salary_range = fields.Selection(selection=[('less_than_5000', 'Less than 5000'),('5000_to_10000', '5000 - 10000'),('10000_to_15000', '10000 - 15000'),('greater_than_15000', 'Greater than 15000')],string='Salary Range')
    x_exp_range = fields.Selection(selection=[('less_than_1', 'Less than 1'),('1_to_3', '1 to 3'),('3_to_6', '3 to 6'),('6_to_10', '6 to 10'),('10_to_15', '10 to 15'),('greater_than_15', 'Greater than 15')],string='Exp. Range')
    x_pre_training = fields.Selection(selection=[('pass', 'Pass'),('fail', 'Fail')],string='Pre Training Score:')
    x_post_training = fields.Selection(selection=[('pass', 'Pass'),('fail', 'Fail')],string='Post Training Score:')
    x_session_attended = fields.Selection(selection=[('partial', 'Partial'),('full', 'Full')],string='Session Attended')
    x_additional_duties = fields.Char(string="Additional Duties")
    x_disability = fields.Char(string="Disability")
    x_training_avaluation = fields.Selection(selection=[('10perc', '10%'),('20perc', '20%'),('30perc', '30%'),('40perc', '40%'),('50perc', '50%'),('60perc', '60%'),('70perc', '70%'),('80perc', '80%'),('90perc', '90%'),('100perc', '100%')],string='Training Evaluation')
    x_smart_phone_availability = fields.Boolean('Smart Phone Availability')

    _defaults = {
        'x_smart_phone_availability': True,
    }
