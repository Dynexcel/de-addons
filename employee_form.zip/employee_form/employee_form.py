from openerp import models, fields, api, exceptions, _


class partner_form(models.Model):
    _name = "res.partner"
    _inherit = 'res.partner'


    district = fields.Char('District/Agency')
    tehsil = fields.Char('Tehsil')
    uc = fields.Char('UC')
    area = fields.Char('Area')
    sub_area = fields.Char('Sub Area')