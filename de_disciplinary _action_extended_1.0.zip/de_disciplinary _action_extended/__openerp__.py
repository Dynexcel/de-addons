# -*- coding: utf-8 -*-
{
    'name': "Disciplinary Action Extended",

    'summary': """Disciplinary Action Module Customized Form""",

    'description': """
Managing Employee Directory Module in Odoo.
=========================================
By adding following form, fields and manu item:
    * It will create Menuitem Action within parent Menuitem Disciplinary Actions
    * Create Action form having following fields:
        * Type
        * Revision
        * Employee
        * Advised By
        * Reason
        * Revision
        * Issue Date
    """,

    'author': "Dynexcel",
    'website': "http://www.dynexcel.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base','hr'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'disciplinary_view.xml',

    ],
    # only loaded in demonstration mode
    'demo': [

    ],
}