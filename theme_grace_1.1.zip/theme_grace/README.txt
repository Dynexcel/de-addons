Steps to install theme

1. Unzip "dependency.zip" in a seprate folder.
2. Go to Theme folder, go to __openerp__.py uncomment "73lines Depend Modules"
3. keep theme and dependent module in addons path.
4. update modules list before installing theme.

If you have not received it,please contact us at enquiry@73lines.com with proof of your purchase.