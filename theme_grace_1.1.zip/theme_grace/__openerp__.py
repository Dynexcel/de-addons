# -*- coding: utf-8 -*-
# Part of Odoo Module Developed by 73lines
# See LICENSE file for full copyright and licensing details.


{
    'name': "Theme Grace",
    'description': 'Theme Grace By 73Lines',
    'category': "Theme/Ecommerce",
    'version': "1.4",
    'author': "73Lines",

    'data': [
            'views/assets.xml',
            'views/mid_header_template.xml',
            'views/customize_model.xml',
            'views/product_template.xml',
            'views/single_product_template.xml',
            'views/s_product_carousel.xml',

            # Snippets
            'views/snippet_main_banner.xml',
            'views/snippet_three_images.xml',
            'views/banner_footer_image.xml',
            'views/snippet_footer.xml',


    ],
    'demo': [
        'data/home_page.xml',
        'data/brand_demo.xml',
        'data/blog_post_demo.xml',
        'data/nav_demo.xml',
        'data/s_footer_template.xml',
    ],


    'depends': [
        # Default Modules

        'theme_default',
        'website',
        'website_animate',
        'mass_mailing',


        # 73lines Depend Modules

        # Don't forget to see README file in order to how to install
        # In order to install complete theme, uncomment the following dependency.
        # Dependent modules are supplied in a zip file along with the theme,
        # if you have not received it,please contact us at
        # enquiry@73lines.com with proof of your purchase.

                 'snippet_blog_carousel_73lines',
                 'snippet_boxed_73lines',
                 'snippet_brand_carousel_73lines',
                 'snippet_object_carousel_73lines',
                 'snippet_product_carousel_73lines',
                 'snippet_product_category_carousel_73lines',
                 'snippet_recently_viewed_products_carousel_73lines',
                 'website_category_banner_73lines',
                 'website_customize_model_73lines',
                 'website_language_flag_73lines',
                 'website_mega_menu_73lines',
                 'website_mid_header_73lines',
                 'website_mid_header_sale_73lines',
                 'website_product_by_brand_73lines',
                 'website_product_content_block_73lines',
                 'website_product_features_73lines',
                 'website_product_multi_image_73lines',
                 'website_product_price_filter_73lines',
                 'website_product_share_button_73lines',
                 'website_product_sorting_73lines',
                 'website_product_tags_73lines',
                 'website_user_wishlist_73lines',
    ],

    'images': [
        'static/description/grace-banner.png',
    ],

    'price': 200,
    'license': 'OEEL-1',
    'currency': 'EUR',
    'live_test_url': 'http://theme-grace.73lines.com'
}
