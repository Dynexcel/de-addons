# -*- coding: utf-8 -*-

import offspring_report
import fattening_report
import thermo_report
import corral_report

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
