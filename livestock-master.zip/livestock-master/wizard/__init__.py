# -*- coding: utf-8 -*-

import livestock_offspring_wizard
import livestock_thermo_wizard
import livestock_corral_wizard
import livestock_fattening_wizard

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
