# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class livestock(models.Model):
#     _name = 'livestock.livestock'

#     name = fields.Char()