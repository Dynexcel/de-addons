odoo.define('product_inquiry.product_inquiry', function (require) {
    var ajax = require('web.ajax');
    $(document).ready(function () {
        clear_function = function() {
            $('#description').val(" ");
            $('#quantity').val(0);
        }

        $("#inquiry_now").click(function(){
            if($("#inquiry_now").attr("data")){
                return location.assign("/web/login");
            }
            $('#myModal').modal('show');
        });
        $('#incoterm_close').on('click', function(evt){
            clear_function()
        });
        $('#incoterm_save').on('click', function(evt){
            $('#myModal').modal('hide');
            var product = $('#product').val();
            var description = $('#description').val();
            var quantity = $('#quantity').val();
            var incoterm = $('#incoterm option:selected').val();
            ajax.jsonRpc('/user/inquiry', 'call', {
                    'product': parseInt(product),
                    'description': description,
                    'quantity': quantity,
                    'incoterm': parseInt(incoterm)
            });
            clear_function();
        });
    });
});