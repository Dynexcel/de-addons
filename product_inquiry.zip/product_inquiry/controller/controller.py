# -*- coding: utf-8 -*-

from openerp import SUPERUSER_ID
from openerp.addons.web import http
from openerp.addons.web.http import request
from openerp.addons.website_sale.controllers.main import website_sale

class website_sale_options(website_sale):
    @http.route(['/shop/product/<model("product.template"):product>'], type='http', auth="public", website=True)
    def product(self, product, category='', search='', **kwargs):
        r = super(website_sale_options, self).product(product, category, search, **kwargs)

        cr, uid, context, pool = request.cr, request.uid, request.context, request.registry
        template_obj = pool['stock.incoterms']
        public_id = pool['ir.model.data'].get_object_reference(cr, uid, 'base', 'public_user')[1]
 
        r.qcontext['optional_incoterms'] = template_obj.search_read(cr, SUPERUSER_ID, [],['name'])
        r.qcontext['quser_id'] = public_id == uid
        return r

    @http.route(['/user/inquiry'], type='json', auth='public', website=True)
    def inquiry(self, product, description='', quantity = 0, incoterm = 0, **kwargs):
        cr, uid, context, pool = request.cr, request.uid, request.context, request.registry
        template_obj = pool['crm.lead']
        res_user = pool['res.users'].browse(cr, SUPERUSER_ID, uid)
        product = pool['product.template'].browse(cr, SUPERUSER_ID, product)

        values = {
            'name': "website inquery about {0}".format(product.name),
            'product': product.id,
            'quantity': quantity,
            'description': description,
            'partner_id': res_user.partner_id.id
        }
        if incoterm != 0:
            values['incoterm'] = incoterm

        template_obj.create(cr, SUPERUSER_ID, values)
