openerp.pos_orders = function(instance, module){
module = instance.point_of_sale;
var QWeb = instance.web.qweb;
_t = instance.web._t;

var ClientListScreenWidgetSuper =module.ClientListScreenWidget.include({
        template: 'ClientListScreenWidget',
    show: function(){

            var self = this;
            this._super();

            $('.view_all_order').on( "click",function() {
              self.pos_widget.screen_selector.set_current_screen('wkorderlist',{'customer_id':this.id});
            });
        },
}); 
module.OrderListScreenWidget = module.ScreenWidget.extend({
        template: 'OrderListScreenWidget',
         show_leftpane:   false,
        previous_screen: 'products',
        
       
        get_customer: function(){
            var ss = this.pos_widget.screen_selector;
            if(ss){
                return ss.get_current_screen_param('customer_id');
            }else{
                return undefined;
            }
        },
        display_order:function(intput_txt){
            var self = this;
            customer_id = this.get_customer();
            var order_list=self.pos.get('pos_order_list');
            var new_order_data=[];
            if(customer_id !=undefined){
                for(i=0;i<order_list.length;i++)
                {
                    if(order_list[i].partner_id[0] == customer_id)
                    {
                    new_order_data=new_order_data.concat(order_list[i]);
                    }
                }
               order_list=new_order_data;
            }
            new_order_data=[];
            if(intput_txt != undefined && intput_txt != ''){
                var search_text =intput_txt.toLowerCase()
                for(i=0;i<order_list.length;i++)
                {

                if(order_list[i].partner_id == '')
                {
                order_list[i].partner_id =[0,'-'];
                }
                if(((order_list[i].name.toLowerCase()).indexOf(search_text) != -1) ||((order_list[i].partner_id[1].toLowerCase()).indexOf(search_text) != -1 ))
                        {
                            new_order_data=new_order_data.concat(order_list[i]);
                        }
                    }
                    order_list=new_order_data;
            }

            var contents = this.$el[0].querySelector('.order-list-contents');
            contents.innerHTML = "";
            for(var i = 0, len = Math.min(order_list.length,1000); i < len; i++){
                var partner    = order_list[i];
                var orderline_html = QWeb.render('WkOrderLine',{widget: this, order_list:order_list[i]});
                var orderline = document.createElement('tbody');
                orderline.innerHTML = orderline_html;
                orderline = orderline.childNodes[1];

                if(i%2==0){
                    orderline.classList.add('highlight');
                }else{
                    orderline.classList.remove('highlight');
                }

                contents.appendChild(orderline);
            }
        },
        show: function(){
            var self = this;
            this._super();
            
            this.display_order(undefined);
            this.$('.order_search').keyup(function(){
                self.display_order(this.value);
            });
            this.$('.back').click(function(){
                self.pos_widget.screen_selector.set_current_screen(self.previous_screen);
            });
        },
    });
var PosModelSuper = module.PosModel
    module.PosModel = module.PosModel.extend({
    load_server_data: function(){
        var self = this;

        var loaded = PosModelSuper.prototype.load_server_data.call(this);
        loaded = loaded.then(function(){
                 var order_lines=[]
                    return self.fetch(
                            'pos.order',
                            ['id','name','date_order','partner_id','lines','is_return_order','return_order_id','return_status'],
                            [['session_id','=',self.pos_session.name],['state','not in',['draft','cancel']],['is_return_order','=',false]])
                    .then(function(orders){
                        self.set({'pos_order_list' : orders});   
                       
                        for(i=0;i<orders.length;i++){
                            order_lines=order_lines.concat(orders[i]['lines']);
                            } 
                        self.fetch(
                            'pos.order.line',
                            ['product_id','order_id','qty'],
                            [['id','in',order_lines]]).then(function(orderlines){
                                self.set({'pos_order_line_list' : orderlines});   
                                
          
                            });
                    });
                });
        return loaded;
        },
        _flush_orders: function (orders, options) {
            var self = this;
            var flush = PosModelSuper.prototype._flush_orders.call(this,orders, options);
            loaded = flush.then(function(server_ids){
                if(server_ids != undefined && server_ids.length != 0)
                   { 
                    var order_lines=[];
                    self.fetch(
                            'pos.order',
                            ['id','name','date_order','partner_id','lines','is_return_order','return_order_id','return_status'],
                            [['id','in',server_ids],['is_return_order','=',false]])
                        .then(function(orders_b){
                        var orders_data= self.get('pos_order_list');
                        var full_order = orders_b.concat(orders_data);
                        self.set({'pos_order_list' : full_order});
                        for(i=0;i<orders_b.length;i++){
                             order_lines=order_lines.concat(orders_b[i]['lines']);
                            } 
                        self.fetch(
                            'pos.order.line',
                            ['product_id','order_id','qty'],
                            [['id','in',order_lines]]).then(function(orderlines){
                                var orders_line_data= self.get('pos_order_line_list');
                                var full_order_lines = orderlines.concat(orders_line_data);
                                self.set({'pos_order_line_list' : full_order_lines});   
                                
          
                            });    
                    });
                }

            });
            return flush;
        },
});


    module.PosWidget.include({
        build_widgets: function(){
            var self = this;
            this._super();

           
                
                this.orderList_screen = new module.OrderListScreenWidget(this,{});
                this.orderList_screen.appendTo(this.$('.pos-content'));
                this.screen_selector.add_screen('wkorderlist',this.orderList_screen);

                var orderList = $(QWeb.render('OrderListButton'));

                orderList.click(function(){
                    
                        self.pos_widget.screen_selector.set_current_screen('wkorderlist',{'customer_id':undefined});
                    
                });
                
                orderList.appendTo(this.$('.control-buttons'));
                this.$('.control-buttons').removeClass('oe_hidden');
            
        },
    });

    
}