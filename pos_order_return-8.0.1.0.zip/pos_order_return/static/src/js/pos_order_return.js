openerp.pos_order_return = function(instance, module){
module = instance.point_of_sale;
var QWeb = instance.web.qweb;
_t = instance.web._t;

//added By Mohit ---start
var _super_order = module.Order.prototype;
    module.Order = module.Order.extend({
        set_return_data: function(original_order_id) {
            this.is_return_order = true;
            this.return_order_id = original_order_id;
        },
        set_returned:function(status) {
            this.return_status = status;
        },
        get_return_data: function() {
            return [this.is_return_order || false,this.return_order_id || false,this.return_status || '-'];
        },
        export_as_JSON: function() {
            var old_order = _super_order.export_as_JSON.call(this);
            var new_values = {
                is_return_order: this.get_return_data()[0],
                return_order_id: this.get_return_data()[1],
                return_status: this.get_return_data()[2],
            }
            $.extend(old_order, new_values);
            return old_order;
        },
    });
//added By Mohit ---stop

var _super_PosModel = module.PosModel;
    var models = _super_PosModel.prototype.models;
    for(var i = 0; i < models.length; i++){
        var model = models[i];
        if(model.model === 'product.product'){
            model.fields.push('not_returnable');
        }
    }


module.PaypadButtonWidget = module.PaypadButtonWidget.extend({
       
        renderElement: function() {
            var self = this;
            this._super();
            this.$el.off();
            this.$el.click(function(){
                if (self.pos.get('selectedOrder').get('screen') === 'receipt'){  //TODO Why ?
                    console.warn('TODO should not get there...?');
                    return;
                }
                var order = self.pos.get('selectedOrder');
                var flag=false;
                for(var i =0; i< order.attributes.orderLines.length; i++){
                   if(order.attributes.orderLines.models[i].product.not_returnable && order.attributes.orderLines.models[i].quantity < 0){
                    flag = true;
                   }
                   


                }
                if(flag){
                    self.pos_widget.screen_selector.set_current_screen('products');

                    alert("In your Order Some products are not returnable")
                }
                else{
                    self.pos.get('selectedOrder').addPaymentline(self.cashregister);
                    self.pos_widget.screen_selector.set_current_screen('payment');
                    }
            });
        },
    });

setTimeout(function(){ 
module.OrderListScreenWidget.include({
         show: function(){
            var self = this;
            this._super();
            this.$('.wk_return_content').click(function(options){ 
            var order_list=self.pos.get('pos_order_list');
            var order_line_data=self.pos.get('pos_order_line_list');           
            var order_id=this.id;
            var order = self.pos.get('selectedOrder');
            var flag = false;
            var message = '';
            var allow_return = true;
            var order_index = false;

            for(i=0;i<order_list.length;i++)
            {  
                if(order_list[i].id == this.id)
                    {
                    order_index = i;
                    order.set_client(self.pos.db.get_partner_by_id(order_list[i].partner_id[0]));
                    if (order_list[i]['return_status'] !== '-')
                    {
                        flag = true;
                        message = 'Sorry, You can`t return same order twice !!'
                        allow_return = false;
                    }
                    break;
                    }
            }
            if (allow_return)
            {
                for(i=0;i<order_line_data.length;i++)
                {
                    if(order_line_data[i].order_id[0] == this.id)
                    {
                        var product = self.pos.db.get_product_by_id(order_line_data[i].product_id[0]);
                        order.addProduct(product,{quantity: - order_line_data[i].qty});
                        if(product.not_returnable){
                            flag = true;
                            message = 'This order contains some Non-Returnable products, so remove them before proceeding !'
                        }
                    }
                }  
                 if(flag)
                {
                    self.pos.pos_widget.screen_selector.show_popup('confirm',{
                        message: _t('Warning !!!'),
                        comment: _t(message),
                        confirm: function(){
                            order.set_returned('Partially-Returned');
                            order.set_return_data(order_id);
                            order_list[order_index]['return_status']='Partially-Returned';
                            self.pos.set({'pos_order_list' : order_list});
                            self.pos_widget.screen_selector.set_current_screen(self.previous_screen);
                        },
                    });                
                }
                else{
                    order.set_return_data(order_id);
                    order.set_returned('Fully-Returned');
                    order_list[order_index]['return_status']='Fully-Returned';
                    self.pos.set({'pos_order_list' : order_list});
                    self.pos_widget.screen_selector.set_current_screen('payment');
                }
            }
            else
            {
                self.pos_widget.screen_selector.show_popup('error-traceback',{
                        message: _t('Not Allowed !!!'),
                        comment: _t(message)
                    });
            }

            })                
            
        },
        
    });
}, 1);
}
