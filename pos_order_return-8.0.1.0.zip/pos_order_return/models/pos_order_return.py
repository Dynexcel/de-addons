# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
#################################################################################
from openerp.osv import fields, osv
from openerp.tools.translate import _
import logging
from openerp import netsvc
from openerp import tools
_logger = logging.getLogger(__name__)

class ProductTemplate(osv.osv):
	_inherit = 'product.template'
	_columns = {
	'not_returnable':fields.boolean('Not Returnable'),	
	}

class pos_order(osv.osv):
	_inherit = 'pos.order'
	def create_from_ui(self, cr, uid, orders, context=None):
		order_ids = super(pos_order, self).create_from_ui(cr, uid, orders, context=context)
		for tmp_order in orders:
			if tmp_order['data']['is_return_order']:
				try:
					self.write(cr,uid,tmp_order['data']['return_order_id'],{'return_status':tmp_order['data']['return_status']})
				except Exception as e:
					_logger.error('Could not write return order status for POS Order: %s, error %s'%(tmp_order['data']['name'],tools.ustr(e)))
		return order_ids
	def _order_fields(self, cr, uid, ui_order, context=None):
		res = super(pos_order, self)._order_fields(cr, uid, ui_order, context=None)
		res.update({
			'is_return_order': ui_order.get('is_return_order') or False,
			'return_order_id': ui_order.get('return_order_id') or False,
		})
		return res

