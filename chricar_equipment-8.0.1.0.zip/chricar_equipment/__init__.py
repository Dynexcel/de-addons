##############################################
#
# ChriCar Beteiligungs- und Beratungs- GmbH
# created 2009-07-11 14:41:58+02
##############################################
import equipment

