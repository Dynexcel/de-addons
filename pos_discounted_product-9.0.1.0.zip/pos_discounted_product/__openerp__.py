# -*- coding: utf-8 -*-
#################################################################################
#
#   Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#   See LICENSE file for full copyright and licensing details.
#################################################################################
{
    'name': 'POS Show Discounted Price',
    'summary': 'Now show discounted price along with base price of the products on point of sale.',
# "license": 'OpenERP AGPL + Private Use',    
'version': '1.0',
    'category': 'Point Of Sale',
    "sequence": 1,
    'description': """
Point Of Sale - Show Discounted Price
=====================================

Salient Features:
----------------
    * Using Price-list, apply discount on products in Point-of-Sale.
    * Show discounted price along with actual price in Point-of-Sale.
    * No need to replace your point of sale, just install this module and you have this feature.



**Help and Support**
================
.. |icon_features| image:: pos_discounted_product/static/description/icon-features.png
.. |icon_support| image:: pos_discounted_product/static/description/icon-support.png
.. |icon_help| image:: pos_discounted_product/static/description/icon-help.png  

* For DOCUMENTATION  - click here ( `VIEW BLOG <http://webkul.com/blog/openerp-pos-show-discount-products>`_  ) 
* For DEMO           - click here ( `VIEW DEMO <http://54.251.33.126:8038/?db=POS_Extensions>`_  ) 

|icon_help| `Help <https://webkul.com/ticket/open.php>`_ |icon_support| `Support <https://webkul.com/ticket/open.php>`_ |icon_features| `Request new Feature(s) <https://webkul.com/ticket/open.php>`_ 

""",
    "author": "Webkul Software Pvt. Ltd.",
    'website': 'http://www.webkul.com',
    'depends': [
        'point_of_sale',
        ],
    'qweb': [
        'static/src/xml/pos_dis_price.xml',
    ],
    "installable": True,
    "application": True,
    "auto_install": False,
       "price": 20, 
    "currency": 'EUR',
        "images":['static/description/Banner.png'],
}
