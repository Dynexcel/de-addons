# -*- coding: utf-8 -*-
{
    'name': "Event Module Extension",

    'summary': """Event Module Customized Form""",

    'description': """
Managing Event Module in Odoo.
=========================================
By adding following fields in Event form:
    * Trainer
    * Time in
    * Time out
    * Hide Assigned to field
Following fields in Registration form:
    * Time in
    * Time out
    * Salary Range
    * Exp. Range
    * Pre Training Score:
    * Post Training Score:
Following fields in Partner form:
    * CNIC#
    * Phone
    """,

    'author': "Dynexcel",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/openerp/addons/base/module/module_data.xml
    # for the full list
    'category': 'Marketing',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base','board','event','hr'],

    'data': [
        'event_form_view.xml'

    ],


    # always loaded

    # only loaded in demonstration mode
    'demo': [

    ],
}