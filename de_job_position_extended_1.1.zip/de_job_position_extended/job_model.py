from openerp import models, fields, api, exceptions, _


class job_position(models.Model):
    _inherit = 'hr.job'

    x_sanctioned_opsition = fields.Integer(string="Sanctioned Position")
