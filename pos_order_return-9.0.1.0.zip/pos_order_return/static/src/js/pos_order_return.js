odoo.define('pos_order_return.pos_order_return', function (require) {
"use strict";
var pos_orders = require('point_of_sale.pos_orders');
var Model = require('web.DataModel');
var ActionManager1 = require('web.ActionManager');
var core = require('web.core');
var models = require('point_of_sale.models');
var _t = core._t;
var PosBaseWidget = require('point_of_sale.BaseWidget');
models.load_fields('product.product','not_returnable');
setTimeout(function(){ 
 
 PosBaseWidget.include({

    renderElement: function() {
      
        var self = this;
        this._super();
        $('.pay').addClass('pay2');
        $('.pay').off();
        $('.pay2').click(function(){
            var order = self.pos.get_order();
            
                var flag=false;
                for(var i =0; i< order.orderlines.length; i++){
                   if(order.orderlines.models[i].product.not_returnable && order.orderlines.models[i].quantity < 0){
                    flag = true;
                   }
                }
                if(flag){
                    
                     self.gui.show_screen('products'); 
                    alert("In your Order Some products are not returnable")
                }
                else{
                     self.gui.show_screen('payment');
                    
                }   
        });
        
    }
});
}, 1000);

pos_orders.include({
     show: function(){
            var self = this;
            this._super();
            this.$('.wk_return_content').click(function(options){ 
            var order_line_data=self.pos.wk_order_lines;           
            var order_id=this.id;
            var order =self.pos.get_order();
            var flag = false
            for(var i=0;i<order_line_data.length;i++)
            {
                if(order_line_data[i].order_id[0] == this.id)
                {
                    var product = self.pos.db.get_product_by_id(order_line_data[i].product_id[0]);
                    
                    if(product.not_returnable){
                        flag = true;
                    }

                    order.add_product(product,{quantity:-parseInt(order_line_data[i].qty)});
                    
                }
            }  
            if(flag)
            {
                self.gui.show_screen('products'); 

                alert("In your Order Some products are not returnable");
            }
            else{
             self.gui.show_screen('payment'); 
            }

            })                
            
        },
  });
});

