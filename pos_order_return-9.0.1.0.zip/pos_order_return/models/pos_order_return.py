# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
#################################################################################
from openerp.osv import fields, osv
from openerp.tools.translate import _
import time
import logging
from datetime import datetime
from openerp import netsvc

class ProductTemplate(osv.osv):
	_inherit = 'product.template'
	_columns = {
	'not_returnable':fields.boolean('Not Returnable'),
	
	}

