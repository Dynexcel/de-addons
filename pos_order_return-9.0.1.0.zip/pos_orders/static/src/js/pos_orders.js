
odoo.define('point_of_sale.pos_orders', function (require) {
"use strict";
var Model = require('web.DataModel');
var screens = require('point_of_sale.screens');
var gui = require('point_of_sale.gui');
var models = require('point_of_sale.models');
var utils = require('web.utils');
var core = require('web.core');
var QWeb     = core.qweb;

models.load_models([{
        model: 'pos.order',
        fields: ['id','name','date_order','partner_id','lines'],
        domain: function(self){ return [['session_id','=',self.pos_session.name],['state','not in',['draft','cancel','done']]]; },
        loaded: function(self,wk_order){ 
            self.wk_order = wk_order; 
     
        },
    },
    {
        model: 'pos.order.line',
                            
        fields: ['product_id','order_id','qty'],
        domain: function(self){  
        	var order_lines=[]
        	var orders=self.wk_order;
        	for(var i=0;i<orders.length;i++){
                    order_lines=order_lines.concat(orders[i]['lines']);
                } 
        	return [['id','in',order_lines]]; 
        },
        loaded: function(self,wk_order_lines){ 
            self.wk_order_lines = wk_order_lines; 
        },
    },
],{'after': 'product.product'});

var _super_posmodel = models.PosModel.prototype;
models.PosModel = models.PosModel.extend({
	        _flush_orders: function (orders, options) {
            var self = this;

            var flush = _super_posmodel._flush_orders.call(this,orders, options);
            var loaded = flush.then(function(server_ids){

                if(server_ids != undefined && server_ids.length != 0)
                   { var order_lines=[];
                    var posOrderModel = new Model('pos.order');
                    posOrderModel.call('wk_order_list',{"wk_order_ids":server_ids}
		                ).then(function (order_data) {
		                    var orders_datas= self.wk_order;
		                    self.wk_order = order_data.concat(orders_datas);
				        	var orders=order_data;
				        	for(var i=0;i<orders.length;i++){
				        		if(orders[i]['lines']!=undefined)
				               order_lines=order_lines.concat(orders[i]['lines']);
				                }
		                 posOrderModel.call('wk_order_line_list',{"wk_order_line_ids":order_lines}
		                	).then(function (order_line_data) {
		                    var orders_datas= self.wk_order_lines;
		                    self.wk_order_lines = order_line_data.concat(orders_datas);
		                
		                });
		                });
		            }

            });
            return flush;
        },
});
var OrdersScreenWidget = screens.ScreenWidget.extend({
    template: 'OrdersScreenWidget',

    init: function(parent, options){
        this._super(parent, options);
      },
      render_list: function(order,intput_txt){
      	
      	var new_order_data=[];
        if(intput_txt != undefined && intput_txt != ''){
            var search_text =intput_txt.toLowerCase()
            for(var i=0;i<order.length;i++)
            {

            if(order[i].partner_id == '')
            {
            order[i].partner_id =[0,'-'];
            }
            if(((order[i].name.toLowerCase()).indexOf(search_text) != -1) ||((order[i].partner_id[1].toLowerCase()).indexOf(search_text) != -1 ))
                    {
                        new_order_data=new_order_data.concat(order[i]);
                    }
                }
                order=new_order_data;
        }

        var contents = this.$el[0].querySelector('.wk-order-list-contents');
        contents.innerHTML = "";
        var wk_orders=order; 
        for(var i = 0, len = Math.min(wk_orders.length,1000); i < len; i++){
            var wk_order    = wk_orders[i];
            var orderline; //= this.order_cache.get_node(wk_orders.id);
            var orderline_html = QWeb.render('WkOrderLine',{widget: this, partner:wk_orders[i]});
            var orderline = document.createElement('tbody');
            orderline.innerHTML = orderline_html;
            orderline = orderline.childNodes[1];
            contents.appendChild(orderline);
        }
    },
     show: function(){
        var self = this;
        this._super();
        var orders=self.pos.wk_order;
        this.render_list(orders,undefined);

        this.$('.order_search').keyup(function(){
                self.render_list(orders,this.value);
            });

        this.$('.back').click(function(){
           self.gui.show_screen('products');
        });
        
        
    },
     close: function(){
        this._super();
        this.$('.wk-order-list-contents').undelegate();
    },
    
    });


gui.define_screen({name:'wk_orders', widget: OrdersScreenWidget});
var OrdersButtonWidget = screens.ActionButtonWidget.extend({
    template: 'OrdersButtonWidget',
    button_click: function(){
        self=this;
         self.gui.show_screen('wk_orders');
        
    },
});

screens.define_action_button({
    'name': 'All Orders',
    'widget': OrdersButtonWidget,
    'condition': function(){
        return true;
    },
});
return OrdersScreenWidget;
});


