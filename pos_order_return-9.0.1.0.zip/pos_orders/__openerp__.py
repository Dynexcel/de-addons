# -*- coding: utf-8 -*-
#################################################################################
#
#    Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#
#################################################################################
{
    "name": "POS All Orders List",
    "category": 'point_of_sale',
    "summary":"""
        POS All Orders List model display all old orders and this model linked with POS order reprint and POS Reorder. 
       """,
    "description": """ 
    POS All Orders List model display all old orders and this model linked with POS order reprint and POS Reorder.
    "",

====================
**Help and Support**
====================
.. |icon_features| image:: pos_orders/static/src/img/icon-features.png
.. |icon_support| image:: pos_orders/static/src/img/icon-support.png
.. |icon_help| image:: pos_orders/static/src/img/icon-help.png

|icon_help| `Help <https://webkul.com/ticket/open.php>`_ |icon_support| `Support <https://webkul.com/ticket/open.php>`_ |icon_features| `Request new Feature(s) <https://webkul.com/ticket/open.php>`_
    """,
    "sequence": 1,
    "author": "Webkul Software Pvt. Ltd.",
    "website": "http://www.webkul.com",
    "version": '1.0',
    "depends": ['point_of_sale'],
    "data": [
        
        'views/pos_orders_view.xml',
        # 'security/ir.model.access.csv',
    ],
   
    'qweb': [
        'static/src/xml/*.xml',
    ],
    "images":['static/description/Banner.png'],
    "installable": True,
    "application": True,
    "auto_install": False,
"price": 27,
    "currency": 'EUR',
}