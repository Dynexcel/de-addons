from openerp.osv import fields, osv
from datetime import datetime
import logging
from openerp import SUPERUSER_ID
_logger = logging.getLogger(__name__)

class pos_order(osv.osv):
	_inherit = 'pos.order'
			
	def wk_order_list(self, cr, uid,wk_order_ids,context={}):
		if wk_order_ids:
			order_obj  = self.pool.get('pos.order').read(cr,uid,wk_order_ids,['id','name','date_order','partner_id','lines'])
			return order_obj
		return False
		
	def wk_order_line_list(self, cr, uid,wk_order_line_ids,context={}):
		if wk_order_line_ids:
			order_obj  = self.pool.get('pos.order.line').read(cr,SUPERUSER_ID,wk_order_line_ids,['product_id','order_id','qty'])
			return order_obj
		return False
    
        
        
