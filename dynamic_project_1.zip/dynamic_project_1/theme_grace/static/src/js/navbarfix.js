$(document).ready(function(){
       $(window).bind('scroll', function() {
       var navHeight = $( window ).height() / 3 - 70;
             if ($(window).scrollTop() > navHeight) {
                 $('.navbar').addClass('navbar-fixed-top container-fluid');
                 $('.navbar').removeClass('container');
                 $(".navbar-default").css('background-color', '#F89D0E');
                  $(".navbar-default .navbar-nav>li>.active").css('background-color', '#F89D0E');
             }
             else {
                 $('.navbar').removeClass('navbar-fixed-top');
                 $(".navbar-default").css('background-color', '#000');
             }
        });
       
           $("html").niceScroll({
               cursorcolor: "#424242", // change cursor color in hex
               cursoropacitymin: 0, // change opacity when cursor is inactive (scrollabar "hidden" state), range from 1 to 0
               cursoropacitymax: 1, // change opacity when cursor is active (scrollabar "visible" state), range from 1 to 0
               cursorwidth: "5px", // cursor width in pixel (you can also write "5px")
               cursorborder: "1px solid #fff", // css definition for cursor border
               cursorborderradius: "5px", // border radius in pixel for cursor
               zindex: "5000",
           });
    });

$("#back-top").hide();
//fade in #back-top
$(function() {
	$(window).scroll(function() {
		if ($(this).scrollTop() > 100) {
			$('#back-top').fadeIn();
		} else {
			$('#back-top').fadeOut();
		}
	});
	// scroll body to 0px on click
	$('#back-top a').click(function() {
		$('body,html').animate({
			scrollTop : 0
		}, 800);
		return false;
	});
});
