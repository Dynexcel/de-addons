# -*- coding: utf-8 -*-

from openerp import fields, models, _
from openerp.exceptions import UserError
from openerp import api


class OcReportLedgerByPartnerInvoices(models.TransientModel):
    _inherit = "account.common.account.report"
    _name = "oc.report.ledger.by.partner.invoices"
    _description = "Open Invoices Report"

    result_selection = fields.Selection([('customer', 'Receivable Accounts'),
                                        ('supplier', 'Payable Accounts'),
                                        ('customer_supplier', 'Receivable and Payable Accounts')
                                      ], string="Partner's", required=True, default='customer')
    initial_balance = fields.Boolean(string='Include Initial Balances',
                                    help='If you selected date, this field allow you to add a row to display the amount of debit/credit/balance that precedes the filter you\'ve set.')
    sortby = fields.Selection([('sort_date', 'Date'), ('sort_journal_partner', 'Journal & Partner')], string='Sort by', required=True, default='sort_date')
    journal_ids = fields.Many2many('account.journal', 'oc_report_ledger_invoices_journal_rel', 'account_id', 'journal_id', string='Journals', required=True, default=lambda self: self.env['account.journal'].search([]))
    partner_ids = fields.Many2many('res.partner', 'oc_report_ledger_invoices_partner_rel', 'partner_id', 'wiz_id', string='Partner')

    @api.multi
    def check_report(self):	
        res = super(OcReportLedgerByPartnerInvoices, self).check_report()
	diarios=[]
        for d in self.env['account.journal'].search([]):
		diarios.append(d.id)
        res['data']['form']['used_context']['journal_ids'] = diarios

        return res

    def _print_report(self, data):
        data = self.pre_print_report(data)
        data['form'].update(self.read(['initial_balance', 'sortby', 'result_selection', 'partner_ids'])[0])
        if data['form'].get('initial_balance') and not data['form'].get('date_from'):
            raise UserError(_("You must define a Start Date"))
        return self.env['report'].with_context(landscape=True).get_action(self, 'oc.report_ledgerbypartnerinvoices', data=data)
