# -*- coding: utf-8 -*-

import account_report_general_ledger_by_partner
import account_report_general_ledger_invoices
